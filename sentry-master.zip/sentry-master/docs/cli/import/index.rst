`sentry import SRC`
-------------------

Imports data from a Sentry export.

Options
```````

- ``--help``: print this help page.
