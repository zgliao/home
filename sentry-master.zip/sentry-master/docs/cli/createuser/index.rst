`sentry createuser`
-------------------

Create a new user.

Options
```````






- ``--help``: print this help page.
