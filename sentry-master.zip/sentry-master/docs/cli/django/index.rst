`sentry django [MANAGEMENT_ARGS]...`
------------------------------------

Execute Django subcommands.

Options
```````

- ``--help``: print this help page.
