`sentry queues purge QUEUE`
---------------------------

Purge all messages from a queue.

Options
```````

- ``-f, --force``: Do not prompt for confirmation.
- ``--help``: print this help page.
