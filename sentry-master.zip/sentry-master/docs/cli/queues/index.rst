`sentry queues`
---------------

Manage Sentry queues.

Options
```````

- ``--help``: print this help page.

Subcommands
```````````

.. toctree::
 :maxdepth: 1

 purge <purge/index>
 list <list/index>
