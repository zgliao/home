`sentry queues list`
--------------------

List queues and their sizes.

Options
```````

- ``-S``: Sort by size.
- ``-r``: Reverse the sort order.
- ``--help``: print this help page.
