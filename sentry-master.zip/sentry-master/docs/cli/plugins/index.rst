`sentry plugins`
----------------

Manage Sentry plugins.

Options
```````

- ``--help``: print this help page.

Subcommands
```````````

.. toctree::
 :maxdepth: 1

 list <list/index>
