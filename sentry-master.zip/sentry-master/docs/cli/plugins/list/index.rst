`sentry plugins list`
---------------------

List all installed plugins

Options
```````

- ``--help``: print this help page.
