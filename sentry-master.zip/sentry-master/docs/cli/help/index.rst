`sentry help`
-------------

Show this message and exit.

Options
```````

- ``--help``: print this help page.
