`sentry tsdb`
-------------

Tools for interacting with the time series database.

Options
```````

- ``--help``: print this help page.

Subcommands
```````````

.. toctree::
 :maxdepth: 1

 query <query/index>
