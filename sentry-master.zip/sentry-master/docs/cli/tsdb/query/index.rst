`sentry tsdb query`
-------------------

Execute queries against the time series database.

Options
```````

- ``--help``: print this help page.

Subcommands
```````````

.. toctree::
 :maxdepth: 1

 organizations <organizations/index>
