`sentry tsdb query organizations [METRICS]...`
----------------------------------------------

Fetch metrics for organizations.

Options
```````



- ``--help``: print this help page.
