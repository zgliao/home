`sentry run`
------------

Run a service.

Options
```````

- ``--help``: print this help page.

Subcommands
```````````

.. toctree::
 :maxdepth: 1

 worker <worker/index>
 web <web/index>
 cron <cron/index>
 smtp <smtp/index>
