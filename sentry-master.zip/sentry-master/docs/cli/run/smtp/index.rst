`sentry run smtp`
-----------------

Run inbound email service.

Options
```````

- ``-b, --bind ADDRESS``: Bind address.
- ``--upgrade``: Upgrade before starting.
- ``--noinput``: Do not prompt the user for input of any kind.
- ``--help``: print this help page.
