`sentry init [DIRECTORY]`
-------------------------

Initialize new configuration directory.

Options
```````

- ``--dev``: Use settings more conducive to local development.
- ``--help``: print this help page.
