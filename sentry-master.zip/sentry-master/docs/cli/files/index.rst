`sentry files`
--------------

Manage files from filestore.

Options
```````

- ``--help``: print this help page.

Subcommands
```````````

.. toctree::
 :maxdepth: 1

 info <info/index>
 get <get/index>
