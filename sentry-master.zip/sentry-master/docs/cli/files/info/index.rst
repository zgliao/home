`sentry files info FILE_ID`
---------------------------

Show a file's metadata by id.

Options
```````


- ``--help``: print this help page.
