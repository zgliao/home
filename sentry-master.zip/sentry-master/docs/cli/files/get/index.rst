`sentry files get FILE_ID`
--------------------------

Fetch a file's contents by id.

Options
```````

- ``--help``: print this help page.
