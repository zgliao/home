`sentry start [SERVICE]`
------------------------

DEPRECATED see `sentry run` instead.

Options
```````

- ``-b, --bind ADDRESS``: Bind address.
- ``-w, --workers INTEGER``: The number of worker processes for handling
  requests.
- ``--upgrade``: Upgrade before starting.
- ``--noinput``: Do not prompt the user for input of any kind.
- ``--help``: print this help page.
