`sentry config list [PATTERN]`
------------------------------

List configuration options.

Options
```````

- ``--help``: print this help page.
