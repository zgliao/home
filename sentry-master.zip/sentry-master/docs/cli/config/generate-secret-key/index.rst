`sentry config generate-secret-key`
-----------------------------------

Generate a new cryptographically secure secret key value.

Options
```````

- ``--help``: print this help page.
