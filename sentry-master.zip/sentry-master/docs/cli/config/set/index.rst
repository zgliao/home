`sentry config set KEY [VALUE]`
-------------------------------

Set a configuration option to a new value.

Options
```````

- ``--secret``: Hide prompt input when inputing secret data.
- ``--help``: print this help page.
