`sentry config delete OPTION`
-----------------------------

Delete/unset a configuration option.

Options
```````

- ``--no-input``: Do not show confirmation.
- ``--help``: print this help page.
