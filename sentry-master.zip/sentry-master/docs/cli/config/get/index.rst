`sentry config get OPTION`
--------------------------

Get a configuration option.

Options
```````

- ``-q, --silent``: Suppress extraneous output.
- ``--help``: print this help page.
