`sentry shell [MANAGEMENT_ARGS]...`
-----------------------------------

Run a Python interactive interpreter.

Options
```````

- ``--help``: print this help page.
