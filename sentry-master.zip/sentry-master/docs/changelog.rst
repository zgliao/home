Changelog
=========

Here you can see the full list of changes between each Sentry server
release.

.. sentry:edition:: self

    .. include:: ../CHANGES

.. sentry:edition:: hosted, on-premise

    .. include:: ../../doc-modules/sentry/CHANGES
