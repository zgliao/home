## Feedback, Advice, and General Help

If you're looking to provide general feedback, or get help or advice, please
utilize our [community forum](https://forum.sentry.io/) rather than GitHub Issues.

## Contributing to Sentry

Want to contribute towards this repository? Follow the server
development documentation
[here](https://docs.sentry.io/internal/).
